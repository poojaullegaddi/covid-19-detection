## COVID 19 Data visualization Dashboard
    Visualizing covid-19 data across all geographical locations  to create DataVisualization Dashboard using tableau-2020
                                      (Dataset as of 6th june 2020)
   
<br></br>    
    To view dashboard:

   1. Visit the google page(https://public.tableau.com/shared/ZS3NC68S7?:display_count=y&:origin=viz_share_link)

                                                OR

   2. download raw file in repository and open with Tableau (you need to be installed tableau public on your PC)
